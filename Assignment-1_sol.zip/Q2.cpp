#include<iostream>
using namespace std;

int main() {
    int x;
    float y;
    char c;
    cin >> x;
    cin >> y;
    cin >> c;
    cout << x << " " << y << " " << c << endl;
    return 0;
}