#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    cout << num << ((num % 2 == 0) ? " is Even" : " is Odd") << endl;

    return 0;
}
