#include <iostream>
#include <iomanip> // for setw
using namespace std;

int main() {
    int roll = 101;
    string name = "Kanav";
    float marks = 95.75;

    // Using \n
    cout << "Student Details:\n";
    
    // Using \t for alignment
    cout << "Roll:\t" << roll << "\n";
    cout << "Name:\t" << name << "\n";
    cout << "Marks:\t" << marks << "\n";

    // Using \b (backspace removes last character)
    cout << "Hello\b World" << endl; // "Hell World"

    // Using endl
    cout << "This is line 1" << endl;
    cout << "This is line 2" << endl;

    // Using setw for tabular formatting
    cout << "\nFormatted Table:\n";
    cout << setw(10) << "Roll" << setw(15) << "Name" << setw(10) << "Marks" << endl;
    cout << setw(10) << roll << setw(15) << name << setw(10) << marks << endl;

    return 0;
}
