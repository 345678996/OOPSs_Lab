#include <iostream>
using namespace std;

int main() {
    int a = 10, b = 5;
    // Using += operator
    a += b;  // same as a = a + b
    cout << "\nAfter a += b;" << endl;
    cout << "a = " << a << " (since a = a + b)" << endl;

    // Using -= operator
    b -= 3;  // same as b = b - 3
    cout << "\nAfter b -= 3;" << endl;
    cout << "b = " << b << " (since b = b - 3)" << endl;

    return 0;
}
