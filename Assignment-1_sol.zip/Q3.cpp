#include<iostream>
using namespace std;

int main() {
    int x, y;
    cout << "Enter 1st number: ";
    cin >> x;
    cout << "Enter 2nd number";
    cin >> y;
    cout << x+y << endl;
    cout << x - y << endl;
    cout << x / y << endl;
    return 0;
}