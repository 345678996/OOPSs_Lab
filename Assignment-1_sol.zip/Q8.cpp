#include <iostream>
using namespace std;

int main() {
    int daysLate;
    cout << "Enter number of days late: ";
    cin >> daysLate;

    if (daysLate <= 0) {
        cout << "No fine. Thank you for returning on time!" << endl;
    } 
    else if (daysLate <= 5) {
        cout << "Fine: 50 paise" << endl;
    } 
    else if (daysLate <= 10) {
        cout << "Fine: 1 rupee" << endl;
    } 
    else if (daysLate <= 30) {
        cout << "Fine: 5 rupees" << endl;
    } 
    else {
        cout << "Membership Cancelled due to delay of more than 30 days!" << endl;
    }

    return 0;
}
