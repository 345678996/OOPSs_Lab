#include<iostream>
using namespace std;

int main() {
    int temp;
    cout << "Enter temp in Celsius: ";
    cin >> temp;
    int tempInFarenheit = temp + 273;
    cout << tempInFarenheit << endl;

    return 0;
}